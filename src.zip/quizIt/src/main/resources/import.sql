/*
 * QUIZITUSER
 */

INSERT INTO QUIZITUSER (USERID, EMAIL, HASH, SALT, USERNAME, USERTYPE) VALUES (1, 'admin@gmail.com', '43b736e9962a4c3770988dcf9f5e04e2092e99f221fb1ce29b999d000b17ad44fe8e0ea8ffc568bcd6281038eefade86b8619bb0a8701f18eb2d1f01f0a07a50','eea6b26a3dd7573f7d03e54f9830091515e2', 'Admin', 'Admin')
INSERT INTO QUIZITUSER (USERID, EMAIL, HASH, SALT, USERNAME, USERTYPE) VALUES (2, 'eval1@gmail.com', 'b3cebc62562010715347f121274f861aba6b81f968c2730ab748812a6de719e5e992ccc2e476977c30674df9641bf39be6b6bf2b17f7e304022df8630c07913f','896f92629e084967b11892d98cd9f9b52e35', 'Evaluator 1', 'Evaluator')
INSERT INTO QUIZITUSER (USERID, EMAIL, HASH, SALT, USERNAME, USERTYPE) VALUES (3, 'eval2@gmail.com', 'bc28f93a2e697d33ac018c847ee62fbed86da8dfdf2284bcc8b6ae89f9f0b2d17892db40e76107964fa551aa3d0bc5730b3578e2ebcb49af6da13b0b274939bc','4c3959c2769c11ead2b060a26f01258f7458', 'Evaluator 2', 'Evaluator')
INSERT INTO QUIZITUSER (USERID, EMAIL, HASH, SALT, USERNAME, USERTYPE) VALUES (4, 'admin1@gmail.com', '2f0772c464701cfd6ff646b4435e3100073eb22a52e44cfeafcd4fee03b998e8904ff7f3649da2a7835c4f8f75b08fd93b8ffc30a7230e1f886355674716b363','6290a87e6894ddf621bc920b80d995e5ad49', 'Admin 1', 'Admin')
INSERT INTO QUIZITUSER (USERID, EMAIL, HASH, SALT, USERNAME, USERTYPE) VALUES (5, 'admin2@gmail.com', '5ebdc5b3abfa070177596c7e7970d051c9222ebf05d3302865d687e994ab368d1f2e0663d262c4db359b4d10ab3dad0bd23ce4262b0d16871410ed53123caa1a','56df8700746b5b0fbd2e2939726a682fa6d9', 'Admin 2', 'Admin')
--insert into hibernate_sequences(sequence_name, sequence_next_hi_value) values('QuizItUser', 6);
/*
 * STUDENTDATA
 */
INSERT INTO STUDENTDATA (STUDENTID, CODESCORE, QUIZSCORE, HASH, SALT, STUDENTEMAIL, STUDENTNAME) VALUES (1, 10.0, 0.0, '2108c41ad339f606483511d006338389c5a9456790c6f56c1c5758b92313369ebf05c82ee264ff9c22924f5532d97c890bf47810e1d17724ecfc1068ae7ee843','771f49f4878b746417753b438fa504dee838', 'sanjay@gmail.com', 'Sanjay')
INSERT INTO STUDENTDATA (STUDENTID, CODESCORE, QUIZSCORE, HASH, SALT, STUDENTEMAIL, STUDENTNAME) VALUES (2, 0.0, 3.0, '9cfc79da4bf28e278a0971dab550d78c1455184bb82d557aedd31d8e81cc73eb11824bf50247cf8c074c67872152d55c55bfa700e7a870a541d1f5f7fd74c4d0','0bdc8b822c8295a77cc961a2d7f0f5926270', 'ram@gmail.com', 'Ram')
--insert into hibernate_sequences(sequence_name, sequence_next_hi_value) values('StudentData', 3);
/*
 * QUESTION
 */
INSERT INTO QUESTION(ID, ANSWER, DESCRIPTION, LANGUAGE, OPTIONA, OPTIONB, OPTIONC, OPTIOND) VALUES (  1, '$_myvar', 'Which of the following is a legal identifier in java ?',   'Java', '2variable', '#myvar', '+@$var',   '$_myvar');
INSERT INTO QUESTION(ID, ANSWER, DESCRIPTION, LANGUAGE, OPTIONA, OPTIONB, OPTIONC, OPTIOND) VALUES (  2, 'String', 'Which of these is NOT a valid keyword or reserved word in Java ?',   'Java', 'default', 'null', 'String',   'volatile');
INSERT INTO QUESTION(ID, ANSWER, DESCRIPTION, LANGUAGE, OPTIONA, OPTIONB, OPTIONC, OPTIOND) VALUES (  3, '-32768 to 32767', 'Which is the legal range of values for a short ?',   'Java', '-128 to 127', '-256 to 255',   '-32768 to 32767', '0 to 65535');
INSERT INTO QUESTION(ID, ANSWER, DESCRIPTION, LANGUAGE, OPTIONA, OPTIONB, OPTIONC, OPTIOND) VALUES (  4, 'int a[ ] [ ] = new int [ ] [4];',   'Which of the following Array declaration statement is illegal ?',   'Java', 'int [ ] a [ ] = new int [4] [4];',   'int a[ ][ ] = new int [4] [4];',   'int a[ ] [ ] = new int [ ] [4];',   'int [ ] a [ ] = new int [4] [ ];');
INSERT INTO QUESTION(ID, ANSWER, DESCRIPTION, LANGUAGE, OPTIONA, OPTIONB, OPTIONC, OPTIOND) VALUES (  5, '%', 'Which operator will always evaluate all the Operands?',   'Java', '||', '&&', '?:', '%');
INSERT INTO QUESTION(ID, ANSWER, DESCRIPTION, LANGUAGE, OPTIONA, OPTIONB, OPTIONC, OPTIOND) VALUES (  6, 'Constructor', 'A special method that is used to initialize a class object ?',   'Java', 'abstract method', 'static method',   'Constructor', 'overloaded method');
INSERT INTO QUESTION(ID, ANSWER, DESCRIPTION, LANGUAGE, OPTIONA, OPTIONB, OPTIONC, OPTIOND) VALUES (  7, 'finalize()', 'Which method is called by Garbage collection thread just before collecting eligible Objects ?',   'Java', 'finally()', 'finalize()',   'final()', 'gc()');
INSERT INTO QUESTION(ID, ANSWER, DESCRIPTION, LANGUAGE, OPTIONA, OPTIONB, OPTIONC, OPTIOND) VALUES (  8, 'JVM', 'Garbage Collection in java is done by who?',   'Java', 'Java Compiler', 'Object class',   'JVM', 'System class');
INSERT INTO QUESTION(ID, ANSWER, DESCRIPTION, LANGUAGE, OPTIONA, OPTIONB, OPTIONC, OPTIOND) VALUES (  9, 'instanceof operator', 'Which operator is used to check object-type at runtime?',   'Java', 'ternary operator', 'instanceof operator',   'type operator', 'length operator');
INSERT INTO QUESTION(ID, ANSWER, DESCRIPTION, LANGUAGE, OPTIONA, OPTIONB, OPTIONC, OPTIOND) VALUES (  10, 'import static keyword', 'You can import only static members of a class present in some other package using __________?',   'Java', 'import keyword', 'import static keyword',   'package keyword', 'static import keyword');
INSERT INTO QUESTION(ID, ANSWER, DESCRIPTION, LANGUAGE, OPTIONA, OPTIONB, OPTIONC, OPTIOND) VALUES (  11, 'Call stack', 'In Java, each thread has its own ________, in which it runs ?',   'Java', 'main() method', 'JVM', 'Call stack',   'Memory');
INSERT INTO QUESTION(ID, ANSWER, DESCRIPTION, LANGUAGE, OPTIONA, OPTIONB, OPTIONC, OPTIOND) VALUES (  12, 'NORM_PRIORITY(5)', 'In Java, by default every thread is given a _________ .',   'Java', 'MIN_PRIORITY(0)', 'NORM_PRIORITY(5)',   'MAX_PRIORITY(10)', 'Any Random Priority');
INSERT INTO QUESTION(ID, ANSWER, DESCRIPTION, LANGUAGE, OPTIONA, OPTIONB, OPTIONC, OPTIOND) VALUES (  13, 'IllegalStateException', 'What Exception is thrown when you start a thread twice ?',   'Java', 'InterruptedException',   'NullPointerException', 'IOException',   'IllegalStateException');
INSERT INTO QUESTION(ID, ANSWER, DESCRIPTION, LANGUAGE, OPTIONA, OPTIONB, OPTIONC, OPTIOND) VALUES (  14, 'run()', 'Which method will contain the body of the thread ?',   'Java', 'run()', 'start()', 'stop()',   'main()');
INSERT INTO QUESTION(ID, ANSWER, DESCRIPTION, LANGUAGE, OPTIONA, OPTIONB, OPTIONC, OPTIOND) VALUES (  15, 'Object', 'Which class or interface defines the wait(), notify(), and notifyAll() methods ?',   'Java', 'Object', 'Thread', 'Runnable',   'Class');
INSERT INTO QUESTION(ID, ANSWER, DESCRIPTION, LANGUAGE, OPTIONA, OPTIONB, OPTIONC, OPTIOND) VALUES (  16, 'Auto-Unboxing', '________ is a process by which the value of object is automatically extracted from a type wrapper?',   'Java', 'Autoboxing', 'Auto-Unboxing',   'Encapsualtion', 'Abstraction');
INSERT INTO QUESTION(ID, ANSWER, DESCRIPTION, LANGUAGE, OPTIONA, OPTIONB, OPTIONC, OPTIOND) VALUES (  17, 'PrintStream class', 'Which of the following class defines print() and println() method ?',   'Java', 'System class', 'InputStream class',   'Object class', 'PrintStream class');
INSERT INTO QUESTION(ID, ANSWER, DESCRIPTION, LANGUAGE, OPTIONA, OPTIONB, OPTIONC, OPTIOND) VALUES (  18, 'Serialization', 'Process of converting an object into a sequence of bytes which can be persisted is called ?',   'Java', 'Serialization', 'Deserialization',   'Synchronization', 'Externalization');
INSERT INTO QUESTION(ID, ANSWER, DESCRIPTION, LANGUAGE, OPTIONA, OPTIONB, OPTIONC, OPTIOND) VALUES (  19, 'transient', 'Which of the following modifier is used to prevent a property from being serialized ?',   'Java', 'strictfp', 'native', 'transient',   'volatile');
INSERT INTO QUESTION(ID, ANSWER, DESCRIPTION, LANGUAGE, OPTIONA, OPTIONB, OPTIONC, OPTIOND) VALUES (  20, 'Generic', 'A class or interface that operates on parameterized type is called ?',   'Java', 'TypeWrapper', 'Collection',   'Generic', 'none of the above');
INSERT INTO QUESTION(ID, ANSWER, DESCRIPTION, LANGUAGE, OPTIONA, OPTIONB, OPTIONC, OPTIOND) VALUES (  21, 'char c2 = ' face ';', 'Which one of the following is invalid declaration of a char ?',   'Java', 'char c1 = 064770;', 'char c2 = ' face ';',   'char c3 = 0xbeef;', 'char c4 = ' \uface ';');
--insert into hibernate_sequences(sequence_name, sequence_next_hi_value) values('Question', 22);
/*
 * QUIZRESPONSE
 */

INSERT INTO QUIZRESPONSE (ID,STATUS,STUDENTID,STUDENTRESPONSE,QUESTION_ID) VALUES (1,1,1,'Serialization',18);
INSERT INTO QUIZRESPONSE (ID,STATUS,STUDENTID,STUDENTRESPONSE,QUESTION_ID) VALUES (2,0,1,'MIN_PRIORITY(0)',12);
INSERT INTO QUIZRESPONSE (ID,STATUS,STUDENTID,STUDENTRESPONSE,QUESTION_ID) VALUES (3,0,1,'#myvar',1);
INSERT INTO QUIZRESPONSE (ID,STATUS,STUDENTID,STUDENTRESPONSE,QUESTION_ID) VALUES (4,1,1,'import static keyword',10);
INSERT INTO QUIZRESPONSE (ID,STATUS,STUDENTID,STUDENTRESPONSE,QUESTION_ID) VALUES (5,0,1,'native',19);
INSERT INTO QUIZRESPONSE (ID,STATUS,STUDENTID,STUDENTRESPONSE,QUESTION_ID) VALUES (6,0,1,'stop()',14);
INSERT INTO QUIZRESPONSE (ID,STATUS,STUDENTID,STUDENTRESPONSE,QUESTION_ID) VALUES (7,1,1,'IllegalStateException',13);
INSERT INTO QUIZRESPONSE (ID,STATUS,STUDENTID,STUDENTRESPONSE,QUESTION_ID) VALUES (8,0,1,'0 to 65535',3);
INSERT INTO QUIZRESPONSE (ID,STATUS,STUDENTID,STUDENTRESPONSE,QUESTION_ID) VALUES (9,0,1,'Object class',8);
INSERT INTO QUIZRESPONSE (ID,STATUS,STUDENTID,STUDENTRESPONSE,QUESTION_ID) VALUES (10,0,1,'Object class',17);
INSERT INTO QUIZRESPONSE (ID,STATUS,STUDENTID,STUDENTRESPONSE,QUESTION_ID) VALUES (11,1,1,'finalize()',7);
INSERT INTO QUIZRESPONSE (ID,STATUS,STUDENTID,STUDENTRESPONSE,QUESTION_ID) VALUES (12,0,1,'Autoboxing',16);
INSERT INTO QUIZRESPONSE (ID,STATUS,STUDENTID,STUDENTRESPONSE,QUESTION_ID) VALUES (13,0,1,'int a[ ][ ] = new int [4] [4];',4);
INSERT INTO QUIZRESPONSE (ID,STATUS,STUDENTID,STUDENTRESPONSE,QUESTION_ID) VALUES (14,0,1,'null',2);
INSERT INTO QUIZRESPONSE (ID,STATUS,STUDENTID,STUDENTRESPONSE,QUESTION_ID) VALUES (15,1,1,'Call stack',11);
INSERT INTO QUIZRESPONSE (ID,STATUS,STUDENTID,STUDENTRESPONSE,QUESTION_ID) VALUES (16,0,2,'TypeWrapper',20);
INSERT INTO QUIZRESPONSE (ID,STATUS,STUDENTID,STUDENTRESPONSE,QUESTION_ID) VALUES (17,0,2,'#myvar',1);
INSERT INTO QUIZRESPONSE (ID,STATUS,STUDENTID,STUDENTRESPONSE,QUESTION_ID) VALUES (18,1,2,'transient',19);
INSERT INTO QUIZRESPONSE (ID,STATUS,STUDENTID,STUDENTRESPONSE,QUESTION_ID) VALUES (19,0,2,'gc()',7);
INSERT INTO QUIZRESPONSE (ID,STATUS,STUDENTID,STUDENTRESPONSE,QUESTION_ID) VALUES (20,0,2,'System class',17);
INSERT INTO QUIZRESPONSE (ID,STATUS,STUDENTID,STUDENTRESPONSE,QUESTION_ID) VALUES (21,1,2,'NORM_PRIORITY(5)',12);
INSERT INTO QUIZRESPONSE (ID,STATUS,STUDENTID,STUDENTRESPONSE,QUESTION_ID) VALUES (22,1,2,'Constructor',6);
INSERT INTO QUIZRESPONSE (ID,STATUS,STUDENTID,STUDENTRESPONSE,QUESTION_ID) VALUES (23,0,2,'Externalization',18);
INSERT INTO QUIZRESPONSE (ID,STATUS,STUDENTID,STUDENTRESPONSE,QUESTION_ID) VALUES (24,0,2,'import keyword',10);
INSERT INTO QUIZRESPONSE (ID,STATUS,STUDENTID,STUDENTRESPONSE,QUESTION_ID) VALUES (25,0,2,'length operator',9);
INSERT INTO QUIZRESPONSE (ID,STATUS,STUDENTID,STUDENTRESPONSE,QUESTION_ID) VALUES (26,0,2,'?:',5);
INSERT INTO QUIZRESPONSE (ID,STATUS,STUDENTID,STUDENTRESPONSE,QUESTION_ID) VALUES (27,0,2,'NullPointerException',13);
INSERT INTO QUIZRESPONSE (ID,STATUS,STUDENTID,STUDENTRESPONSE,QUESTION_ID) VALUES (28,0,2,'Autoboxing',16);
INSERT INTO QUIZRESPONSE (ID,STATUS,STUDENTID,STUDENTRESPONSE,QUESTION_ID) VALUES (29,0,2,'JVM',11);
INSERT INTO QUIZRESPONSE (ID,STATUS,STUDENTID,STUDENTRESPONSE,QUESTION_ID) VALUES (30,0,2,'Runnable',15);
--insert into hibernate_sequences(sequence_name, sequence_next_hi_value) values('QuizResponse', 31);
/*
 * CODEQUESTION
 */
INSERT INTO CODEQUESTION (ID,CODECONSTRAIN,CODEQUESTION,SAMPLEINPUT,SAMPLEOUTPUT) VALUES (1,'constrain','this is a code question test','sample input','sample output');
INSERT INTO CODEQUESTION (ID,CODECONSTRAIN,CODEQUESTION,SAMPLEINPUT,SAMPLEOUTPUT) VALUES (2,'constrains','code question 2','sample input ','sample output');
--insert into hibernate_sequences(sequence_name, sequence_next_hi_value) values('CodeQuestion', 3);

/*
 * TESTCASE
 */
INSERT INTO TESTCASE (ID,TESTCASEINPUT,TESTCASEOUTPUT) VALUES (1,'testcase input ','testcase output');
INSERT INTO TESTCASE (ID,TESTCASEINPUT,TESTCASEOUTPUT) VALUES (2,'testcase input 1','testcase output 1');
--insert into hibernate_sequences(sequence_name, sequence_next_hi_value) values('Testcase', 3);
/*
 *	CODEQUESTION_TESTCASE 
 */
INSERT INTO CODEQUESTION_TESTCASE (CODEQUESTION_ID,TESTCASES_ID) VALUES (1,1);
INSERT INTO CODEQUESTION_TESTCASE (CODEQUESTION_ID,TESTCASES_ID) VALUES (2,2);
--insert into hibernate_sequences(sequence_name, sequence_next_hi_value) values('CodeQuestion_Testcase', 3);

/*
 * CODERESPONSE
 */
INSERT INTO CODERESPONSE (ID,SCODE,STUDENTCODE,STUDENTID,CODEQUESTION_ID) VALUES (1,'7075626C696320636C617373204170706C69636174696F6E207B0D0A0D0A097075626C69632073746174696320766F6964206D61696E28537472696E675B5D206172677329207B0D0A090953797374656D2E6F75742E7072696E746C6E2822484922293B0D0A09090D0A097D0D0A0D0A7D',null,1,2);
--insert into hibernate_sequences(sequence_name, sequence_next_hi_value) values('CodeResponse', 2);



