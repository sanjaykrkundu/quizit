package com.zycus.model;

public class ProcessResponse {

	private int responseCode;
	private String error;
	private String output;
	private boolean passed;

	public boolean isPassed() {
		return passed;
	}

	public void setPassed(boolean passed) {
		this.passed = passed;
	}

	public int getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(int responseCode) {
		this.responseCode = responseCode;
	}

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

	public String getOutput() {
		return output;
	}

	public void setOutput(String output) {
		this.output = output;
	}

	@Override
	public String toString() {
		return "ProcessResponse [responseCode=" + responseCode + ", error=" + error + ", output=" + output + ", passed="
				+ passed + "]";
	}

}
