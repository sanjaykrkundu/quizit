/**
 * 
 */
package com.zycus.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;

/**
 * @author sameer.zilpilwar
 *
 */
@Entity
@Table(name = "StudentData")
public class Student {

	@Id
	@GenericGenerator(strategy="increment", name="student_studentid")
	@GeneratedValue(generator="student_studentid")
	int studentId;
	String studentName;
	@Column(unique = true, nullable = false)
	String studentEmail;
	String salt;
	String hash;
	@Transient
	String studentPassword;
	double quizScore;
	double codeScore;

	public Student() {
		super();
	}

	public int getStudentId() {
		return studentId;
	}

	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getStudentEmail() {
		return studentEmail;
	}

	public void setStudentEmail(String studentEmail) {
		this.studentEmail = studentEmail;
	}

	public String getStudentPassword() {
		return studentPassword;
	}

	public void setStudentPassword(String studentPassword) {
		this.studentPassword = studentPassword;
	}

	public double getQuizScore() {
		return quizScore;
	}

	public void setQuizScore(double quizScore) {
		this.quizScore = quizScore;
	}

	public double getCodeScore() {
		return codeScore;
	}

	public void setCodeScore(double codeScore) {
		this.codeScore = codeScore;
	}

	public String getSalt() {
		return salt;
	}

	public void setSalt(String salt) {
		this.salt = salt;
	}

	public String getHash() {
		return hash;
	}

	public void setHash(String hash) {
		this.hash = hash;
	}

	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", studentName=" + studentName + ", studentEmail=" + studentEmail
				+ ", salt=" + salt + ", hash=" + hash + ", studentPassword=" + studentPassword + ", quizScore="
				+ quizScore + ", codeScore=" + codeScore + "]";
	}

}
