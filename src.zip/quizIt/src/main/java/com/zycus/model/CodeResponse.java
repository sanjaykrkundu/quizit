package com.zycus.model;

import java.util.Arrays;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table
public class CodeResponse {

	@Id
	@GenericGenerator(strategy="increment", name="coderesponse_id")
	@GeneratedValue(generator="coderesponse_id")
	int id;
	int studentId;
	@OneToOne
	CodeQuestion codeQuestion;
	String studentCode;
	byte[] sCode;

	public CodeResponse() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getStudentId() {
		return studentId;
	}

	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}

	public CodeQuestion getCodeQuestion() {
		return codeQuestion;
	}

	public void setCodeQuestion(CodeQuestion codeQuestion) {
		this.codeQuestion = codeQuestion;
	}

	public String getStudentCode() {
		return studentCode;
	}

	public void setStudentCode(String studentCode) {
		this.studentCode = studentCode;
	}
	
	public byte[] getsCode() {
		return sCode;
	}

	public void setsCode(byte[] sCode) {
		this.sCode = sCode;
	}

	@Override
	public String toString() {
		return "CodeResponse [id=" + id + ", studentId=" + studentId + ", codeQuestion=" + codeQuestion
				+ ", studentCode=" + studentCode + ", sCode=" + Arrays.toString(sCode) + "]";
	}
}
