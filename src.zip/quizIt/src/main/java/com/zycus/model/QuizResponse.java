package com.zycus.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table
public class QuizResponse {

	@Id
	@GenericGenerator(strategy="increment", name="quizresponce_id")
	@GeneratedValue(generator="quizresponce_id")
	int id;
	int studentId;
	@OneToOne
	Question question;
	String studentResponse;
	boolean status;

	public QuizResponse() {
		super();
	}
	

	public QuizResponse(int id, int studentId, Question question, String studentResponse, boolean status) {
		super();
		this.id = id;
		this.studentId = studentId;
		this.question = question;
		this.studentResponse = studentResponse;
		this.status = status;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Question getQuestion() {
		return question;
	}

	public void setQuestion(Question question) {
		this.question = question;
	}

	public String getStudentResponse() {
		return studentResponse;
	}

	public void setStudentResponse(String studentResponse) {
		this.studentResponse = studentResponse;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public int getStudentId() {
		return studentId;
	}

	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}

	@Override
	public String toString() {
		return "QuizResponse [id=" + id + ", studentId=" + studentId + ", question=" + question + ", studentResponse="
				+ studentResponse + ", status=" + status + "]";
	}

}
