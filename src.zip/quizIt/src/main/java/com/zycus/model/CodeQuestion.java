package com.zycus.model;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table
public class CodeQuestion {

	@Id
	@GenericGenerator(strategy="increment", name="codequestion_id")
	@GeneratedValue(generator="codequestion_id")
	int id;
	String codeQuestion;
	String codeConstrain;
	String sampleInput;
	String sampleOutput;
	@OneToMany(fetch = FetchType.EAGER)
	List<Testcase> testcases;
	
	public CodeQuestion() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCodeQuestion() {
		return codeQuestion;
	}

	public void setCodeQuestion(String codeQuestion) {
		this.codeQuestion = codeQuestion;
	}

	public String getCodeConstrain() {
		return codeConstrain;
	}

	public void setCodeConstrain(String codeConstrain) {
		this.codeConstrain = codeConstrain;
	}

	public String getSampleInput() {
		return sampleInput;
	}

	public void setSampleInput(String sampleInput) {
		this.sampleInput = sampleInput;
	}

	public String getSampleOutput() {
		return sampleOutput;
	}

	public void setSampleOutput(String sampleOutput) {
		this.sampleOutput = sampleOutput;
	}

	public List<Testcase> getTestcases() {
		return testcases;
	}

	public void setTestcases(List<Testcase> testcases) {
		this.testcases = testcases;
	}

	@Override
	public String toString() {
		return "CodeQuestion [id=" + id + ", codeQuestion=" + codeQuestion + ", codeConstrain=" + codeConstrain
				+ ", sampleInput=" + sampleInput + ", sampleOutput=" + sampleOutput + ", testcases=" + testcases + "]";
	}
	
}
