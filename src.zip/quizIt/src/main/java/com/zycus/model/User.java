package com.zycus.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "QuizItUser")
public class User {

	@Id
	@GenericGenerator(strategy = "increment", name = "user_id")
	@GeneratedValue(generator = "user_id")
	int userId;
	String userName;
	String salt;
	String hash;
	@Transient
	String userPassword;
	@Column(unique = true, nullable = false)
	String email;
	String userType;

	public User() {
		super();
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getSalt() {
		return salt;
	}

	public void setSalt(String salt) {
		this.salt = salt;
	}

	public String getHash() {
		return hash;
	}

	public void setHash(String hash) {
		this.hash = hash;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName + ", salt=" + salt + ", hash=" + hash
				+ ", userPassword=" + userPassword + ", email=" + email + ", userType=" + userType + "]";
	}

}
