package com.zycus.model;

import java.util.ArrayList;
import java.util.List;

public class Response {

	ProcessResponse compilResponse;
	List<ProcessResponse> executionResponse;
	int noOfTC;
	int passedTC;

	public Response() {
		executionResponse = new ArrayList<>();
	}

	public ProcessResponse getCompilResponse() {
		return compilResponse;
	}

	public void setCompilResponse(ProcessResponse compilResponse) {
		this.compilResponse = compilResponse;
	}

	public List<ProcessResponse> getExecutionResponse() {
		return executionResponse;
	}

	public void setExecutionResponse(List<ProcessResponse> executionResponse) {
		this.executionResponse = executionResponse;
	}

	public int getNoOfTC() {
		return noOfTC;
	}

	public void setNoOfTC(int noOfTC) {
		this.noOfTC = noOfTC;
	}

	public int getPassedTC() {
		return passedTC;
	}

	public void setPassedTC(int passedTC) {
		this.passedTC = passedTC;
	}

	public void addExecutionResponce(ProcessResponse processResponse) {
		this.executionResponse.add(processResponse);
	}

	@Override
	public String toString() {
		return "Response [compilResponse=" + compilResponse + ", executionResponse=" + executionResponse + ", noOfTC="
				+ noOfTC + ", passedTC=" + passedTC + "]";
	}

}
