package com.zycus.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table
public class Testcase {

	@Id
	@GenericGenerator(strategy="increment", name="testcase_id")
	@GeneratedValue(generator="testcase_id")
	int id;
	String testcaseInput;
	String testcaseOutput;
	
	public Testcase() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTestcaseInput() {
		return testcaseInput;
	}

	public void setTestcaseInput(String testcaseInput) {
		this.testcaseInput = testcaseInput;
	}

	public String getTestcaseOutput() {
		return testcaseOutput;
	}

	public void setTestcaseOutput(String testcaseOutput) {
		this.testcaseOutput = testcaseOutput;
	}

	@Override
	public String toString() {
		return "Testcase [id=" + id + ", testcaseInput=" + testcaseInput + ", testcaseOutput=" + testcaseOutput + "]";
	}

}
