package com.zycus.exceptionHandling;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.zycus.model.Student;
import com.zycus.model.User;

public class LoginHandleFilter implements Filter {

	@Override
	public void destroy() {

	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {

		try {
			HttpServletRequest httpReq = (HttpServletRequest) request;
			HttpSession session = httpReq.getSession();
			// UserSessionObject
			User user = (User) session.getAttribute("UserSessionObject");
			Student student = (Student)session.getAttribute("StudentSessionObject");
			String path = httpReq.getRequestURI().substring(httpReq.getContextPath().length());
			if (user == null || student == null)
				System.out.println(path + " Not Logger in");
			else
				System.out.println(path + "Logged in");
			chain.doFilter(request, response);

		} catch (Exception ex) {
			request.setAttribute("errorMessage", ex);
			request.getRequestDispatcher("/WEB-INF/jsp/error.jsp").forward(request, response);
		}

	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		
	}

}
