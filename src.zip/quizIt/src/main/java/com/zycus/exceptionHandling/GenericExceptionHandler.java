package com.zycus.exceptionHandling;

import org.springframework.http.HttpStatus;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.zycus.exception.ResourceNotFoundException;

@ControllerAdvice
public class GenericExceptionHandler {

	@ResponseStatus(value = HttpStatus.NOT_FOUND)
	@ExceptionHandler(ResourceNotFoundException.class)
	public String pagenotfound(Model model, ResourceNotFoundException e) {
		model.addAttribute("message", "404! Page Not Found");
		return "error";
	}

	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	@ExceptionHandler(Exception.class)
	public String allexception(Model model, Exception e) {
		model.addAttribute("message", "Something Went Wrong!");
		return "error";
	}

}
