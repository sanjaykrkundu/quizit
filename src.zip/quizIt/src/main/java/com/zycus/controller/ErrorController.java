package com.zycus.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.zycus.exception.ResourceNotFoundException;

@Controller
public class ErrorController {

	@RequestMapping(value = "/*", method = RequestMethod.GET)
	public void get404() {
		throw new ResourceNotFoundException();
	}

}
