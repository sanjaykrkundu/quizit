package com.zycus.controller;

import java.util.LinkedList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.zycus.model.CodeQuestion;
import com.zycus.model.Question;
import com.zycus.model.Testcase;
import com.zycus.service.CodeQuestionService;
import com.zycus.service.QuestionService;
import com.zycus.service.TestCaseService;

@Controller
public class AdminController {

	@Autowired
	QuestionService questionService;

	public void setQuestionService(QuestionService questionService) {
		this.questionService = questionService;
	}

	@Autowired
	CodeQuestionService codeQuestionService;
	
	@Autowired
	TestCaseService testCaseService;

	public void setTestCaseService(TestCaseService testCaseService) {
		this.testCaseService = testCaseService;
	}
	
	public void setCodeQuestionService(CodeQuestionService codeQuestionService) {
		this.codeQuestionService = codeQuestionService;
	}

	@RequestMapping(value = { "/addQuestion" }, method = RequestMethod.GET)
	public String getAddQuestionPage(Model model) {
		model.addAttribute("QuestionObject", new Question());
		return "addQuestion";
	}

	@RequestMapping(value = { "/addCodeQue" }, method = RequestMethod.GET)
	public String getAddCodeQuestionPage(Model model) {
		model.addAttribute("CodeQuestionObject", new CodeQuestion());
		return "addCodeQuestion";
	}

	@RequestMapping(value = "/question", method = RequestMethod.POST)
	public String addQuestion(@ModelAttribute("QuestionObject") Question question, Model model) {
		boolean status = questionService.addQuestion(question);
		if (status) {
			model.addAttribute("message", "Question Added successfully");
			model.addAttribute("QuestionObject", new Question());
			return "addQuestion";
		}
		model.addAttribute("message", "Unable to Add Question");
		return "addQuestion";
	}

	@RequestMapping(value = "/codeQuestion", method = RequestMethod.POST)
	public String addCodeQuestion(@ModelAttribute("CodeQuestionObject") CodeQuestion codeQuestion, Model model, HttpServletRequest httpServletRequest) {
		String input=httpServletRequest.getParameter("testcaseInput");
		String output=httpServletRequest.getParameter("testcaseOutput");
		String testcaseInput[] = input.split(",");
		String testcaseOutput[] = output.split(",");
		List<Testcase> testcaseList = new LinkedList<Testcase>();
		if(testcaseInput.length == testcaseOutput.length){
			for (int i = 0; i < testcaseOutput.length; i++) {
				Testcase temp = new Testcase();
				temp.setTestcaseInput(testcaseInput[i]);
				temp.setTestcaseOutput(testcaseOutput[i]);
				Integer id = testCaseService.addTestCase(temp);
				temp.setId(id);
				testcaseList.add(temp);
			}
		}
		codeQuestion.setTestcases(testcaseList);
		boolean status = codeQuestionService.addQuestion(codeQuestion);
		if (status) {
			model.addAttribute("message", "Question Added successfully");
			model.addAttribute("CodeQuestionObject", new CodeQuestion());
			return "addCodeQuestion";
		}
		model.addAttribute("message", "Unable to Add Question");
		model.addAttribute("CodeQuestionObject", new CodeQuestion());
		return "addCodeQuestion";
	}

	@RequestMapping(value = "/viewQuestion", method = RequestMethod.GET)
	public String viewQuestion(Model model) {
		List<Question> allQuestion = questionService.getAllQuestion();
		if (allQuestion.isEmpty()) {
			model.addAttribute("message", "No Questions are found");
			return "Admin";
		}
		model.addAttribute("allQuestion", allQuestion);
		return "viewQuestion";
	}
	
	@RequestMapping(value = "/viewCodeQue", method = RequestMethod.GET)
	public String viewCodeQuestion(Model model) {
		List<CodeQuestion> allQuestion = codeQuestionService.getAllQuestion();
		System.out.println(allQuestion.get(0));
		if (allQuestion.isEmpty()) {
			model.addAttribute("message", "No Questions are found");
			return "Admin";
		}
		model.addAttribute("allCodeQuestion", allQuestion);
		return "viewCodeQuestion";
	}

}
