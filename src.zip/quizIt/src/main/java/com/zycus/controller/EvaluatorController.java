package com.zycus.controller;

import java.nio.charset.StandardCharsets;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.zycus.model.CodeResponse;
import com.zycus.model.QuizResponse;
import com.zycus.model.Student;
import com.zycus.service.CodeResponseService;
import com.zycus.service.QuizResponseService;
import com.zycus.service.StudentService;

@Controller
public class EvaluatorController {

	@Autowired
	StudentService studentService;

	@Autowired
	QuizResponseService quizResponseService;

	@Autowired
	CodeResponseService codeResponseService;

	public void setCodeResponseService(CodeResponseService codeResponseService) {
		this.codeResponseService = codeResponseService;
	}

	public void setQuizResponseService(QuizResponseService quizResponseService) {
		this.quizResponseService = quizResponseService;
	}

	public void setStudentService(StudentService studentService) {
		this.studentService = studentService;
	}

	@RequestMapping(value = "/allStudent", method = RequestMethod.GET)
	public String viewStudent(Model model, HttpSession httpSession) {
		List<Student> allStudent = studentService.getAllStudent();
		httpSession.setAttribute("allStudent", allStudent);
		if (allStudent.isEmpty()) {
			model.addAttribute("message", "No Students are found");
			return "Evaluator";
		}
		model.addAttribute("allStudent", allStudent);
		return "viewStudent";
	}

	@RequestMapping(value = "/Evaluator", method = RequestMethod.GET)
	public String viewhomeEvaluator(Model model, HttpSession httpSession) {
		return "Evaluator";
	}

	
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/studentDetails", method = RequestMethod.POST)
	public String getStudentDetails(Model model, HttpServletRequest httpServletRequest, HttpSession httpSession) {
		List<Student> allStudent = (List<Student>) httpSession.getAttribute("allStudent");
		String email = httpServletRequest.getParameter("studentName");
		Student student = studentService.getStudentByEmail(email);
		List<QuizResponse> quizResponses = quizResponseService.getQuizResponseofStudent(student.getStudentId());
		if (quizResponses.isEmpty()) {
			model.addAttribute("quiz", "Student had not taken the Quiz");
		} else {
			model.addAttribute("quizResponse", quizResponses);
			model.addAttribute("student", student);

		}
		List<CodeResponse> codeResponses = codeResponseService.getCodeResponseofStudent(student.getStudentId());
		if(codeResponses.size()==1){
			model.addAttribute("codeResponse", codeResponses.get(0));
			String studentCode=new String(codeResponses.get(0).getsCode(), StandardCharsets.UTF_8);
			model.addAttribute("studentCode", studentCode);
		}else{
			model.addAttribute("code", "Student had not solved the code");
		}
		httpSession.setAttribute("studentSessionObject", student);
		model.addAttribute("allStudent", allStudent);
		return "viewStudent";
	}
}
