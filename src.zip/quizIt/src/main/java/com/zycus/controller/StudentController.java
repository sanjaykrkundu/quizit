package com.zycus.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;

import com.zycus.model.CodeQuestion;
import com.zycus.model.CodeResponse;
import com.zycus.model.Question;
import com.zycus.model.QuizResponse;
import com.zycus.model.Response;
import com.zycus.model.Student;
import com.zycus.service.CodeQuestionService;
import com.zycus.service.CodeResponseService;
import com.zycus.service.QuestionService;
import com.zycus.service.QuizResponseService;
import com.zycus.service.StudentService;
import com.zycus.utils.Executor;

@Controller
public class StudentController {

	@Autowired
	StudentService studentService;

	@Autowired
	QuestionService questionService;

	@Autowired
	CodeQuestionService codeQuestionService;

	@Autowired
	QuizResponseService quizResponseService;

	@Autowired
	CodeResponseService codeResponseService;

	public void setCodeResponseService(CodeResponseService codeResponseService) {
		this.codeResponseService = codeResponseService;
	}

	public void setQuizResponseService(QuizResponseService quizResponseService) {
		this.quizResponseService = quizResponseService;
	}

	public void setCodeQuestionService(CodeQuestionService codeQuestionService) {
		this.codeQuestionService = codeQuestionService;
	}

	public void setQuestionService(QuestionService questionService) {
		this.questionService = questionService;
	}

	public void setStudentService(StudentService studentService) {
		this.studentService = studentService;
	}

	@RequestMapping(value = "/studentRegister", method = RequestMethod.POST)
	public String registerUser(@ModelAttribute("StudentObject") Student student, Model model) {
		boolean status = studentService.registerStudent(student);
		if (status) {
			model.addAttribute("message", "Registration successful");
			return "Student";
		}
		model.addAttribute("message", "Email id Already Registered");
		return "studentRegistration";
	}

	@RequestMapping(value = { "/quizInstruction" }, method = RequestMethod.GET)
	public String getQuizInstructionPage() {
		return "quizInstruction";
	}

	@RequestMapping(value = { "/programingInstruction" }, method = RequestMethod.GET)
	public String getCodeInstructionPage() {
		return "programingInstruction";
	}

	@RequestMapping(value = "/quizQuestion", method = RequestMethod.GET)
	public String getQuizQuestionPage(Model model, HttpSession httpSession) {
		Student student = (Student) httpSession.getAttribute("StudentSessionObject");
		List<QuizResponse> quizResponses = quizResponseService.getQuizResponseofStudent(student.getStudentId());
		if (student.getQuizScore() == 0 && quizResponses.isEmpty()) {
			List<Question> question = questionService.getRandomQuestion();
			if (question.isEmpty()) {
				model.addAttribute("message", "No Question are available");
				return "Student";
			}
			model.addAttribute("question", question);
			httpSession.setAttribute("question", question);
			return "quizQuestion";
		}
		model.addAttribute("message", "You had allready taken Quiz Test");
		return "result";
	}

	@RequestMapping(value = "/codeQuestion", method = RequestMethod.GET)
	public String getCodeQuestionPage(Model model, HttpSession httpSession) {
		Student student = (Student) httpSession.getAttribute("StudentSessionObject");
		List<CodeResponse> codeResponses = codeResponseService.getCodeResponseofStudent(student.getStudentId());
		if (student.getCodeScore() == 0 && codeResponses.isEmpty()) {
			CodeQuestion codeQuestion = codeQuestionService.getRandomCodeQuestion();
			model.addAttribute("codeQuestion", codeQuestion);
			httpSession.setAttribute("codeQuestion", codeQuestion);
			return "codeQuestion";
		}
		model.addAttribute("message", "You had allready Done with Programs");
		return "result";

	}

	@RequestMapping(value = "/submitQuiz", method = RequestMethod.POST)
	public String submitQuiz(Model model, HttpServletRequest request, HttpSession httpSession) {
		@SuppressWarnings("unchecked")
		List<Question> question = (List<Question>) httpSession.getAttribute("question");
		Student student = (Student) httpSession.getAttribute("StudentSessionObject");
		double score = 0;
		for (int i = 0; i < 15; i++) {
			String answer = request.getParameter("" + i);
			QuizResponse quizResponse = new QuizResponse();
			quizResponse.setStudentId(student.getStudentId());
			quizResponse.setQuestion(question.get(i));
			if (answer != null) {
				quizResponse.setStudentResponse(answer);
				if (answer.equalsIgnoreCase(question.get(i).getAnswer())) {
					score++;
					quizResponse.setStatus(true);
				}
			} else {
				quizResponse.setStudentResponse("Not Attemted");
				quizResponse.setStatus(false);
			}
			quizResponseService.addQuizResponse(quizResponse);
		}
		student.setQuizScore(score);
		boolean flag = studentService.updateStudent(student);
		if (flag) {
			model.addAttribute("message", "Successfully Submited the Test");
			model.addAttribute("StudentObject", student);
			httpSession.setAttribute("StudentSessionObject", student);
			return "result";
		}
		model.addAttribute("message", "Unable to Submit the Test");
		return "quizQuestion";
	}

	/*
	 * @RequestMapping(value = "/submitCode", method = RequestMethod.POST)
	 * public String submitCode(Model model, HttpServletRequest request,
	 * HttpSession httpSession) { CodeQuestion codeQuestion = (CodeQuestion)
	 * httpSession.getAttribute("codeQuestion"); Student student = (Student)
	 * httpSession.getAttribute("StudentSessionObject"); String option =
	 * request.getParameter("action"); String actualCode =
	 * request.getParameter("code"); String script =
	 * request.getParameter("code"); script =
	 * ProgramUtils.formateScript(script); if (option.equals("Test")) { String
	 * output = ProgramUtils.executeProgram(script,
	 * codeQuestion.getSampleInput()); if (output != null) { boolean report =
	 * ProgramUtils.checkOutput(output); if (report) { String sampleoutput =
	 * ProgramUtils.getOutputMessage(output); model.addAttribute("message",
	 * "Sucessfully Executed"); model.addAttribute("codeQuestion",
	 * codeQuestion); model.addAttribute("StudentObject", student);
	 * model.addAttribute("error", sampleoutput); model.addAttribute("script",
	 * actualCode); httpSession.setAttribute("StudentSessionObject", student);
	 * httpSession.setAttribute("codeQuestion", codeQuestion); return
	 * "codeQuestion"; } } else { model.addAttribute("message",
	 * "Unable to Process Request Due to some technical issue");
	 * model.addAttribute("codeQuestion", codeQuestion);
	 * model.addAttribute("StudentObject", student);
	 * model.addAttribute("script", actualCode);
	 * httpSession.setAttribute("StudentSessionObject", student);
	 * httpSession.setAttribute("codeQuestion", codeQuestion); return
	 * "codeQuestion"; }
	 * 
	 * } else { if (option.equals("Submit")) { double codeScore = 0; for (int i
	 * = 0; i < codeQuestion.getTestcases().size(); i++) { String output =
	 * ProgramUtils.executeProgram(script,
	 * codeQuestion.getTestcases().get(i).getTestcaseInput()); if (output !=
	 * null) { boolean report = ProgramUtils.checkOutput(output); if (report) {
	 * report = ProgramUtils.checkResult(output,
	 * codeQuestion.getTestcases().get(i).getTestcaseOutput()); if (report) {
	 * codeScore = codeScore + 10; System.out.println("For testcase"+i+" : "
	 * +codeScore); } } } else { // Unable to process Code on JDoodle Handle it
	 * model.addAttribute("message",
	 * "Unable to process Code Due to technical issue Code is saved for Evaluation"
	 * ); } } // Update Student Score student.setCodeScore(codeScore);
	 * studentService.updateStudent(student);
	 * 
	 * // Create Code Response and save it CodeResponse codeResponse = new
	 * CodeResponse(); codeResponse.setStudentId(student.getStudentId());
	 * codeResponse.setCodeQuestion(codeQuestion);
	 * codeResponse.setsCode(actualCode.getBytes());
	 * codeResponseService.addCodeResponse(codeResponse);
	 * 
	 * // Diver to Result page model.addAttribute("StudentObject", student);
	 * httpSession.setAttribute("StudentSessionObject", student); return
	 * "result";
	 * 
	 * } else { // Create Code Response and save it CodeResponse codeResponse =
	 * new CodeResponse(); codeResponse.setStudentId(student.getStudentId());
	 * codeResponse.setCodeQuestion(codeQuestion);
	 * codeResponse.setsCode(actualCode.getBytes(Charset.forName("UTF-8")));
	 * codeResponseService.addCodeResponse(codeResponse);
	 * 
	 * // Diver to Result page model.addAttribute("message",
	 * "Code Saved and Score Updated"); model.addAttribute("StudentObject",
	 * student); httpSession.setAttribute("StudentSessionObject", student);
	 * return "result"; }
	 * 
	 * } return "result"; }
	 * 
	 */

	@RequestMapping(value = "/submitCode", method = RequestMethod.POST)
	public String submitCode(Model model, HttpServletRequest request, HttpSession httpSession)
			throws IOException, InterruptedException {
		CodeQuestion codeQuestion = (CodeQuestion) httpSession.getAttribute("codeQuestion");
		Student student = (Student) httpSession.getAttribute("StudentSessionObject");
		String option = request.getParameter("action");
		String script = request.getParameter("code");

		CodeResponse codeResponse = new CodeResponse();
		codeResponse.setCodeQuestion(codeQuestion);
		codeResponse.setStudentCode(script);
		codeResponse.setStudentId(student.getStudentId());
		if (option.equalsIgnoreCase("test")) {
			Response response = Executor.executeCode(codeResponse, true);
			System.out.println(response);
		} else if (option.equalsIgnoreCase("Submit")) {
			Response response = Executor.executeCode(codeResponse, false);
			System.out.println(response);
			System.out.println((response.getPassedTC() * 100.0) / response.getNoOfTC());
		}
		return "result";
	}

	@Autowired
	private RequestMappingHandlerMapping requestMappingHandlerMapping;

	@RequestMapping(value = "/endPoints", method = RequestMethod.GET)
	public String getEndPointsInView(Model model) {
		requestMappingHandlerMapping.getHandlerMethods().keySet().forEach(System.out::println);
		return "index";
	}
}
