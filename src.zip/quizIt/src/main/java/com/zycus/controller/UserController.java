/**
 * 
 */
package com.zycus.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.zycus.model.Student;
import com.zycus.model.User;
import com.zycus.service.StudentService;
import com.zycus.service.UserService;

/**
 * @author sameer.zilpilwar
 *
 */
@Controller
public class UserController {

	@Autowired
	UserService userService;

	public void setUserService(UserService userService) {
		this.userService = userService;
	}

	@Autowired
	StudentService studentService;

	public void setStudentService(StudentService studentService) {
		this.studentService = studentService;
	}

	@RequestMapping(value = { "/", "/index" }, method = RequestMethod.GET)
	public String getHomePage() {
		return "index";
	}

	@RequestMapping(value = "/newUser", method = RequestMethod.GET)
	public String getSignUpPage(Model model) {
		model.addAttribute("UserObject", new User());
		return "newUser";
	}

	@RequestMapping(value = "/Admin", method = RequestMethod.GET)
	public String getAdminPage(Model model) {
		return "Admin";
	}

	@RequestMapping(value = "/adminReg", method = RequestMethod.GET)
	public String getAdminRegPage(Model model) {
		model.addAttribute("UserObject", new User());
		return "adminReg";
	}

	@RequestMapping(value = "/evaluatorReg", method = RequestMethod.GET)
	public String getEvaluatorRegPage(Model model) {
		model.addAttribute("UserObject", new User());
		return "evaluatorReg";
	}

	@RequestMapping(value = "/Student", method = RequestMethod.GET)
	public String getStudentPage(Model model) {
		model.addAttribute("StudentObject", new Student());
		return "Student";
	}

	@RequestMapping(value = "/studentRegistration", method = RequestMethod.GET)
	public String getStudentRegistrationPage(Model model) {
		model.addAttribute("StudentObject", new Student());
		return "studentRegistration";
	}

	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public String registerUser(@ModelAttribute("UserObject") User user, Model model) {
		boolean status = userService.registerUser(user);
		if (status) {
			model.addAttribute("message", "Registration successful");
			return "Admin";
		}
		model.addAttribute("message", "Email id already registered");
		return "adminReg";
	}

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String getLoginPage(Model model) {
		model.addAttribute("UserObject", new User());
		return "login";
	}

	@RequestMapping(value = "/loginprocess", method = RequestMethod.GET)
	public String loginprocess(Model model, HttpSession httpSession) {

		User newUser = (User) httpSession.getAttribute("UserSessionObject");
		if (newUser.getUserType().equals("Admin")) {
			return "Admin";
		}
		if (newUser.getUserType().equals("Evaluator")) {
			return "Evaluator";
		}
		model.addAttribute("message", "Unable to Login");
		return "login";

	}

	@RequestMapping(value = "/loginprocess", method = RequestMethod.POST)
	public String processlogin(@ModelAttribute("UserObject") User user, Model model, HttpSession httpSession) {

		User newUser = userService.login(user.getEmail(), user.getUserPassword());
		if (newUser != null) {
			httpSession.setAttribute("UserSessionObject", newUser);
			if (newUser.getUserType().equals("Admin")) {
				return "Admin";
			}
			if (newUser.getUserType().equals("Evaluator")) {
				return "Evaluator";
			}
		} else {
			Student newStudent = studentService.login(user.getEmail(), user.getUserPassword());
			if (newStudent != null) {
				httpSession.setAttribute("StudentSessionObject", newStudent);
				return "Student";
			}
		}
		model.addAttribute("message", "Unable to Login");
		return "login";
	}

	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logOut(Model model, HttpSession httpSession) {
		httpSession.invalidate();
		model.addAttribute("message", "loggedOut successfully");
		return "index";
	}

}
