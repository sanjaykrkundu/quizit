package com.zycus.utils;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

public class Security {

	public static String getSalt() {
		SecureRandom random = new SecureRandom();
		byte bytes[] = new byte[18];
		random.nextBytes(bytes);
		return byteToHexString(bytes);
	}

	public static String byteToHexString(byte[] bytes) {
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < bytes.length; i++) {
			sb.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
		}
		return sb.toString();
	}

	public static String hash(String salt, String password) {
		MessageDigest md;
		byte[] bytes = null;
		try {
			md = MessageDigest.getInstance("SHA-512");
			md.update(salt.getBytes());
			bytes = md.digest(password.getBytes());
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}

		return byteToHexString(bytes);
	}

}
