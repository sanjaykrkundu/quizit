package com.zycus.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import org.json.JSONObject;

public class ProgramUtils {

	static String clientId = "c1f8fcc91f5639a51d135eba3e2ee21a";
	static String clientSecret = "6c6ed2c58dea6ceb0e1371760fb8d7784136e06c3226b12c3246bf597d2d6c7f";
	String script = "";
	static String language = "java";
	static String versionIndex = "0";

	public static String executeProgram(String code, String testcase) {
		String output = null;
		try {
			URL url = new URL("https://api.jdoodle.com/v1/execute");
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.setDoOutput(true);
			connection.setRequestMethod("POST");
			connection.setRequestProperty("Content-Type", "application/json");

			String input = "{\"clientId\": \"" + clientId + "\",\"clientSecret\":\"" + clientSecret + "\",\"script\":\""
					+ code + "\",\"stdin\":\"" + testcase + "\",\"language\":\"" + language + "\",\"versionIndex\":\""
					+ versionIndex + "\"} ";
			OutputStream outputStream = connection.getOutputStream();
			outputStream.write(input.getBytes());
			outputStream.flush();
			if (connection.getResponseCode() != HttpURLConnection.HTTP_OK) {
				return output;
			}
			BufferedReader bufferedReader;
			bufferedReader = new BufferedReader(new InputStreamReader((connection.getInputStream())));
			output = bufferedReader.readLine();
			connection.disconnect();

		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return output;
	}

	public static String formateScript(String script) {
		String code;
		code = script.replaceAll("[\r\n]", " ");
		code = code.replaceAll("[\"]", "\\\\\"");
		return code;
	}
	
	public static boolean checkOutput(String output){
		JSONObject outputJson = new JSONObject(output);
		if(outputJson.has("output")){
			return true;
		}
		return false;
	}
	
	public static boolean checkResult(String output,String testcaseOutput){
		JSONObject outputJson = new JSONObject(output);
		String result = outputJson.getString("output").replaceAll("[\n]", "");
		if(testcaseOutput.contains(result)){
			return true;
		}
		return false;
	}
	
	public static String getErrorMessage(String output){
		JSONObject outputJson = new JSONObject(output);
		return outputJson.getString("error");
	}
	
	public static String getOutputMessage(String output){
		JSONObject outputJson = new JSONObject(output);
		return outputJson.getString("output");
	}
}
