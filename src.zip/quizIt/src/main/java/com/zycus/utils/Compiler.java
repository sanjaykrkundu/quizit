package com.zycus.utils;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

import com.zycus.model.ProcessResponse;

public class Compiler {

	private static String streamToString(InputStream ins) {
		String temp = null, output = "";
		BufferedReader in = new BufferedReader(new InputStreamReader(ins));
		try {
			while ((temp = in.readLine()) != null) {
				output += "\n" + temp;
			}
		} catch (IOException e) {
			return null;
		}
		return output.replaceFirst("\n", "");
	}

	private static ProcessResponse runProcess(String command, String input) throws Exception {
		ProcessResponse response = new ProcessResponse();
		Process pro = Runtime.getRuntime().exec(command);
		if (input != null) {
			BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(pro.getOutputStream()));
			writer.write(input, 0, input.length());
			writer.newLine();
			writer.close();
		}
		pro.waitFor();
		response.setResponseCode(pro.exitValue());
		response.setError(streamToString(pro.getErrorStream()));
		response.setOutput(streamToString(pro.getInputStream()));

		return response;
	}

	public static ProcessResponse compile(String classPath, String fileName) {
		try {
			return runProcess("javac " + classPath + File.separator + fileName + ".java", null);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public static ProcessResponse run(String classPath, String fileName, String input) {
		try {
			return runProcess("java -Djava.security.manager -cp " + classPath + "; " + fileName, input);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
}