package com.zycus.utils;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

import com.zycus.model.CodeQuestion;
import com.zycus.model.CodeResponse;
import com.zycus.model.ProcessResponse;
import com.zycus.model.Response;
import com.zycus.model.Testcase;

public class Executor {

	public static Response executeCode(CodeResponse codeResponse, boolean testmode)
			throws IOException, InterruptedException {

		// creating temp java file
		File file = File.createTempFile("Question_", ".java");
		String fileName = file.getName().replace(".java", "");

		String code = codeResponse.getStudentCode().replace("public class Question", "public class " + fileName);
		System.out.println(code);
		Files.write(file.toPath(), code.getBytes());
		Thread.sleep(2000);

		String classPath = file.getParentFile().getAbsolutePath();
		Response response = Executor.execute(classPath, fileName, codeResponse.getCodeQuestion(), testmode);

		return response;
	}

	private static Response execute(String classPath, String fileName, CodeQuestion question, boolean testmode) {
		Response response = new Response();
		response.setCompilResponse(Compiler.compile(classPath, fileName));
		System.out.println("===========================================");
		System.out.println("compiler " + response.getCompilResponse());
		System.out.println("===========================================");
		if (response.getCompilResponse().getResponseCode() == 0) {

			ProcessResponse exeRes;

			System.out.println("STC : " + question.getSampleInput() + " - " + question.getSampleOutput());

			/*
			 * run sample test case;
			 */
			response.setNoOfTC(1);
			exeRes = Compiler.run(classPath, fileName, question.getSampleInput());
			if (exeRes.getResponseCode() == 0) {
				if (exeRes.getOutput().equals(question.getSampleOutput())) {
					exeRes.setPassed(true);
					response.setPassedTC(1);
				}
			}
			System.out.println("SOUT " + exeRes);
			response.addExecutionResponce(exeRes);

			/*
			 * run test cases
			 */
			if (!testmode) {
				for (Testcase tc : question.getTestcases()) {
					System.out.println("TC " + tc);

					response.setNoOfTC(response.getNoOfTC() + 1);
					exeRes = Compiler.run(classPath, fileName, tc.getTestcaseInput());
					if (exeRes.getResponseCode() == 0) {
						if (exeRes.getOutput().equals(tc.getTestcaseOutput())) {
							exeRes.setPassed(true);
							response.setPassedTC(response.getPassedTC() + 1);
						}
					}
					System.out.println("OUT " + exeRes);
					response.addExecutionResponce(exeRes);
				}
			}

		}
		System.out.println(response.getExecutionResponse());
		System.out.println("===========================================");

		return response;
	}

}