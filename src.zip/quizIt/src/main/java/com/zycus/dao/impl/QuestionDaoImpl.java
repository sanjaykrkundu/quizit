package com.zycus.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.zycus.dao.QuestionDao;
import com.zycus.model.Question;
@Repository
public class QuestionDaoImpl implements QuestionDao {

	@Autowired
	HibernateTemplate hibernateTemplate;
	
	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}
	
	public boolean addQuestion(Question question) {
		Integer id = (Integer) hibernateTemplate.save(question);
		if (id != null)
			return true;
		return false;
	}

	public List<Question> getAllQuestion() {
		@SuppressWarnings("unchecked")
		List<Question> questionList = (List<Question>) hibernateTemplate.find("from Question", new Object[]{});
		return questionList;
	}

	public boolean deleteQuestion(int queId) {
		return false;
	}

}
