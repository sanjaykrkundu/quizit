package com.zycus.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.zycus.dao.CodeQuestionDao;
import com.zycus.model.CodeQuestion;

@Repository
public class CodeQuestionDaoImpl implements CodeQuestionDao {

	@Autowired
	HibernateTemplate hibernateTemplate;
	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}
	
	
	public boolean addQuestion(CodeQuestion codeQuestion) {
		Integer id = (Integer) hibernateTemplate.save(codeQuestion);
		if (id != null)
			return true;
		return false;
	}

	public List<CodeQuestion> getAllQuestion() {
		List<CodeQuestion> questionList = (List<CodeQuestion>) hibernateTemplate.find("from CodeQuestion", new Object[]{});
		return questionList;
	}

	public boolean deleteCodeQuestion(int queId) {
		return false;
	}

}
