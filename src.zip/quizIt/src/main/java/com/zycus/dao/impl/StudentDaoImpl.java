package com.zycus.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.zycus.dao.StudentDao;
import com.zycus.model.Student;
import com.zycus.utils.Security;

@Repository
public class StudentDaoImpl implements StudentDao {

	@Autowired
	HibernateTemplate hibernateTemplate;

	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}

	public boolean registerStudent(Student student) {
		String query = "from Student where studentEmail=?";
		List<Student> listStudent = (List<Student>) hibernateTemplate.find(query,
				new Object[] { student.getStudentEmail() });
		if (listStudent.isEmpty()) {
			Integer id = (Integer) hibernateTemplate.save(student);
			if (id != null)
				return true;
		}
		return false;
	}

	public Student login(String email) {
		// String query = "from Student where studentEmail=? and hash=?";
		// List<Student> listStudent = (List<Student>)
		// hibernateTemplate.find(query, new Object[] { email, password });
		String query = "from Student where studentEmail=?";
		@SuppressWarnings("unchecked")
		List<Student> listStudent = (List<Student>) hibernateTemplate.find(query, new Object[] { email });
		if (listStudent.size() == 1) {
			return listStudent.get(0);
		}
		return null;
	}

	public boolean updateStudent(Student student) {
		hibernateTemplate.update(student);
		Student id = hibernateTemplate.get(Student.class, student.getStudentId());
		if (id.equals(student))
			return true;
		return false;
	}

	public List<Student> getAllStudent() {
		List<Student> studentList = (List<Student>) hibernateTemplate.find("from Student", new Object[] {});
		System.out.println(studentList);
		return studentList;
	}

	public Student getStudentByEmail(String email) {
		String query = "from Student where studentEmail=?";
		List<Student> listStudent = (List<Student>) hibernateTemplate.find(query, new Object[] { email });
		if (listStudent.size() == 1) {
			return listStudent.get(0);
		}
		return null;
	}

}
