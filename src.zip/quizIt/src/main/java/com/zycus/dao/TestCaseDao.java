package com.zycus.dao;


import com.zycus.model.Testcase;

public interface TestCaseDao {
	public Integer addTestCase(Testcase testcase);
}
