package com.zycus.dao.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.zycus.dao.TestCaseDao;
import com.zycus.model.Testcase;

@Repository
public class TestCaseDaoImpl implements TestCaseDao {

	@Autowired
	HibernateTemplate hibernateTemplate;

	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}

	public Integer addTestCase(Testcase testcase) {
		Integer id = (Integer) hibernateTemplate.save(testcase);
		if (id != null)
			return id;
		return null;
	}

}
