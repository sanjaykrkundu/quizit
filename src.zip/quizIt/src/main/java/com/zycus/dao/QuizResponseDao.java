package com.zycus.dao;

import java.util.List;

import com.zycus.model.QuizResponse;

public interface QuizResponseDao {

		public boolean addQuizResponse(QuizResponse quizResponse);
		public List<QuizResponse> getQuizResponseofStudent(int studentId);
}
