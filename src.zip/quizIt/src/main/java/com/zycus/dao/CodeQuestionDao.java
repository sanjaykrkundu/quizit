package com.zycus.dao;

import java.util.List;

import com.zycus.model.CodeQuestion;

public interface CodeQuestionDao {
	public boolean addQuestion(CodeQuestion codeQuestion);
	public List<CodeQuestion> getAllQuestion();
	public boolean deleteCodeQuestion(int queId);
}
