/**
 * 
 */
package com.zycus.dao;

import com.zycus.model.User;

/**
 * @author sameer.zilpilwar
 *
 */
public interface UserDao {

	public boolean registerUser(User user);
	public User login(String email);
}
