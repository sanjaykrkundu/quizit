package com.zycus.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.zycus.dao.CodeResponseDao;
import com.zycus.model.CodeResponse;

@Repository
public class CodeResponseDaoImpl implements CodeResponseDao {

	@Autowired
	HibernateTemplate hibernateTemplate;

	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}

	public boolean addCodeResponse(CodeResponse codeResponse) {
		Integer id = (Integer) hibernateTemplate.save(codeResponse);
		if (id != null)
			return true;
		return false;
	}

	public List<CodeResponse> getCodeResponseofStudent(int studentId) {
		String query = "from CodeResponse where studentId=?";
		@SuppressWarnings("unchecked")
		List<CodeResponse> codeResponses = (List<CodeResponse>) hibernateTemplate.find(query,
				new Object[] { studentId });
		return codeResponses;
	}

}
