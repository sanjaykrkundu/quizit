/**
 * 
 */
package com.zycus.dao;

import java.util.List;

import com.zycus.model.Question;

/**
 * @author sameer.zilpilwar
 *
 */
public interface QuestionDao {
	public boolean addQuestion(Question question);
	public List<Question> getAllQuestion();
	public boolean deleteQuestion(int queId);
}
