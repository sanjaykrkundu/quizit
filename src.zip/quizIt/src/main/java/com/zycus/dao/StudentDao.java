/**
 * 
 */
package com.zycus.dao;

import java.util.List;

import com.zycus.model.Student;

/**
 * @author sameer.zilpilwar
 *
 */
public interface StudentDao {

	public boolean registerStudent(Student student);
	public Student login(String email);
	public boolean updateStudent(Student student);
	public List<Student> getAllStudent();
	public Student getStudentByEmail(String email);
}
