/**
 * 
 */
package com.zycus.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.zycus.dao.UserDao;
import com.zycus.model.User;

/**
 * @author sameer.zilpilwar
 *
 */
@Repository
public class UserDaoImpl implements UserDao {

	@Autowired
	HibernateTemplate hibernateTemplate;

	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}

	public boolean registerUser(User user) {
		String query = "from User where email=?";
		List<User> listUser = (List<User>) hibernateTemplate.find(query, new Object[] { user.getEmail() });
		if (listUser.isEmpty()) {
			Integer id = (Integer) hibernateTemplate.save(user);
			if (id != null)
				return true;
		}
		return false;
	}

	public User login(String email) {
		String query = "from User where email=? ";
		List<User> listUser = (List<User>) hibernateTemplate.find(query, new Object[] { email });
		if (listUser.size() == 1) {
			return listUser.get(0);
		}
		return null;
	}

}
