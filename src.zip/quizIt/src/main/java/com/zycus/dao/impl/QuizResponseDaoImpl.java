package com.zycus.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.zycus.dao.QuizResponseDao;
import com.zycus.model.QuizResponse;

@Repository
public class QuizResponseDaoImpl implements QuizResponseDao {

	@Autowired
	HibernateTemplate hibernateTemplate;
	
	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}
	
	public boolean addQuizResponse(QuizResponse quizResponse) {
		Integer id = (Integer) hibernateTemplate.save(quizResponse);
		if (id != null)
			return true;
		return false;
	}

	public List<QuizResponse> getQuizResponseofStudent(int studentId) {
		String query = "from QuizResponse where studentId=?";
		@SuppressWarnings("unchecked")
		List<QuizResponse> quizResponses = (List<QuizResponse>) hibernateTemplate.find(query, new Object[] { studentId});
		return quizResponses;
	}

}
