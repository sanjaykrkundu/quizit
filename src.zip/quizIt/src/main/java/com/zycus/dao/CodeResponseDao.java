package com.zycus.dao;

import java.util.List;

import com.zycus.model.CodeResponse;

public interface CodeResponseDao {
	public boolean addCodeResponse(CodeResponse codeResponse);

	public List<CodeResponse> getCodeResponseofStudent(int studentId);
}
