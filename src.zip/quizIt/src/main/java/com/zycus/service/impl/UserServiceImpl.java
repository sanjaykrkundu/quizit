/**
 * 
 */
package com.zycus.service.impl;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zycus.dao.impl.UserDaoImpl;
import com.zycus.model.Student;
import com.zycus.model.User;
import com.zycus.service.UserService;
import com.zycus.utils.Security;

/**
 * @author sameer.zilpilwar
 *
 */
@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserDaoImpl userDaoImpl;

	public void setUserDaoImpl(UserDaoImpl userDaoImpl) {
		this.userDaoImpl = userDaoImpl;
	}

	@Transactional
	public boolean registerUser(User user) {
		String salt = Security.getSalt();
		user.setSalt(salt);
		user.setHash(Security.hash(salt, user.getUserPassword()));
		return userDaoImpl.registerUser(user);
	}

	@Transactional
	public User login(String email, String password) {
		User user = userDaoImpl.login(email);

		if (user != null) {
			if (user.getHash().equals(Security.hash(user.getSalt(), password)))
				return user;
		}

		return null;
	}

}
