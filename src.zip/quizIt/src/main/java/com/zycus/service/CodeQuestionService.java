package com.zycus.service;

import java.util.List;

import com.zycus.model.CodeQuestion;

public interface CodeQuestionService {
	public boolean addQuestion(CodeQuestion codeQuestion);
	public List<CodeQuestion> getAllQuestion();
	public boolean deleteCodeQuestion(int queId);
	public CodeQuestion getRandomCodeQuestion();
}
