package com.zycus.service.impl;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zycus.dao.TestCaseDao;
import com.zycus.model.Testcase;
import com.zycus.service.TestCaseService;

@Service
public class TestCaseServiceImpl implements TestCaseService {

	@Autowired
	TestCaseDao testCaseDao;
	
	public void setTestCaseDao(TestCaseDao testCaseDao) {
		this.testCaseDao = testCaseDao;
	}
	
	
	@Transactional
	public Integer addTestCase(Testcase testcase) {
		return testCaseDao.addTestCase(testcase);
	}

}
