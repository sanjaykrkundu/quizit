package com.zycus.service.impl;

import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zycus.dao.impl.QuestionDaoImpl;
import com.zycus.model.Question;
import com.zycus.service.QuestionService;

@Service
public class QuestionServiceImpl implements QuestionService {

	@Autowired
	QuestionDaoImpl questionDaoImpl;

	@Transactional
	public boolean addQuestion(Question question) {
		return questionDaoImpl.addQuestion(question);
	}

	@Transactional
	public List<Question> getAllQuestion() {
		return questionDaoImpl.getAllQuestion();
	}

	@Transactional
	public boolean deleteQuestion(int queId) {
		return questionDaoImpl.deleteQuestion(queId);
	}

	@Transactional
	public List<Question> getRandomQuestion() {
		List<Question> allQuestion = questionDaoImpl.getAllQuestion();
		List<Question> selectedQuestion = new LinkedList<Question>();
		Random rand = new Random();
		if (!allQuestion.isEmpty()) {
			for (int i = 0; i < 15; i++) {
				int randomIndex = rand.nextInt(allQuestion.size());
				selectedQuestion.add(allQuestion.get(randomIndex));
				allQuestion.remove(randomIndex);
			}
		}
		return selectedQuestion;
	}

}
