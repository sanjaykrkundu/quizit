package com.zycus.service.impl;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zycus.dao.QuizResponseDao;
import com.zycus.model.QuizResponse;
import com.zycus.service.QuizResponseService;

@Service
public class QuizResponseServiceImpl implements QuizResponseService {

	@Autowired
	QuizResponseDao quizResponseDao;

	public void setQuizResponseDao(QuizResponseDao quizResponseDao) {
		this.quizResponseDao = quizResponseDao;
	}

	@Transactional
	public boolean addQuizResponse(QuizResponse quizResponse) {
		return quizResponseDao.addQuizResponse(quizResponse);
	}

	@Transactional
	public List<QuizResponse> getQuizResponseofStudent(int studentId) {
		return quizResponseDao.getQuizResponseofStudent(studentId);
	}

}
