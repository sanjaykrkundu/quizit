package com.zycus.service.impl;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zycus.dao.CodeResponseDao;
import com.zycus.model.CodeResponse;
import com.zycus.service.CodeResponseService;

@Service
public class CodeResponseServiceImpl implements CodeResponseService {

	@Autowired
	CodeResponseDao codeResponseDao;

	public void setCodeResponseDao(CodeResponseDao codeResponseDao) {
		this.codeResponseDao = codeResponseDao;
	}

	@Transactional
	public boolean addCodeResponse(CodeResponse codeResponse) {
		return codeResponseDao.addCodeResponse(codeResponse);
	}

	@Transactional
	public List<CodeResponse> getCodeResponseofStudent(int studentId) {
		return codeResponseDao.getCodeResponseofStudent(studentId);
	}

}
