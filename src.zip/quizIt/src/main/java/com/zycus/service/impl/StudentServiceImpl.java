package com.zycus.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zycus.dao.impl.StudentDaoImpl;
import com.zycus.model.Student;
import com.zycus.service.StudentService;
import com.zycus.utils.Security;

@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	StudentDaoImpl studentDaoImpl;

	public boolean registerStudent(Student student) {
		String salt = Security.getSalt();
		student.setSalt(salt);
		student.setHash(Security.hash(salt, student.getStudentPassword()));
		return studentDaoImpl.registerStudent(student);
	}

	public Student login(String email, String password) {
		Student student = studentDaoImpl.login(email);
		if (student != null) {
			if (student.getHash().equals(Security.hash(student.getSalt(), password)))
				return student;
		}
		return null;
	}

	public boolean updateStudent(Student student) {
		return studentDaoImpl.updateStudent(student);
	}

	public List<Student> getAllStudent() {
		return studentDaoImpl.getAllStudent();
	}

	public Student getStudentByEmail(String email) {
		return studentDaoImpl.getStudentByEmail(email);
	}

}
