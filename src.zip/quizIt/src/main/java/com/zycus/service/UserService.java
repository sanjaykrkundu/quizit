package com.zycus.service;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.zycus.model.User;
@Service
public interface UserService {
	
	@Transactional
	public boolean registerUser(User user);

	@Transactional
	public User login(String email, String password);
}
