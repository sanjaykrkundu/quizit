package com.zycus.service;

import java.util.List;

import com.zycus.model.CodeResponse;

public interface CodeResponseService {
	public boolean addCodeResponse(CodeResponse codeResponse);
	public List<CodeResponse> getCodeResponseofStudent(int studentId);
}
