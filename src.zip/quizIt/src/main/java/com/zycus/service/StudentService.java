package com.zycus.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.zycus.model.Student;

@Service
public interface StudentService {
	@Transactional
	public boolean registerStudent(Student student);

	@Transactional
	public Student login(String email, String password);

	@Transactional
	public boolean updateStudent(Student student);

	@Transactional
	public List<Student> getAllStudent();
	
	@Transactional
	public Student getStudentByEmail(String email);
}
