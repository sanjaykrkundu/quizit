package com.zycus.service;

import org.springframework.stereotype.Service;

import com.zycus.model.Testcase;

@Service
public interface TestCaseService {

	public Integer addTestCase(Testcase testcase);
}
