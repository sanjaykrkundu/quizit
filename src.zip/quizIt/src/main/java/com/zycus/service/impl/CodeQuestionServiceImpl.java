package com.zycus.service.impl;

import java.util.List;
import java.util.Random;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zycus.dao.impl.CodeQuestionDaoImpl;
import com.zycus.model.CodeQuestion;
import com.zycus.service.CodeQuestionService;

@Service
public class CodeQuestionServiceImpl implements CodeQuestionService {

	@Autowired
	CodeQuestionDaoImpl codeQuestionDaoImpl;

	@Transactional
	public boolean addQuestion(CodeQuestion codeQuestion) {
		return codeQuestionDaoImpl.addQuestion(codeQuestion);
	}

	@Transactional
	public List<CodeQuestion> getAllQuestion() {
		return codeQuestionDaoImpl.getAllQuestion();
	}

	@Transactional
	public boolean deleteCodeQuestion(int queId) {
		return codeQuestionDaoImpl.deleteCodeQuestion(queId);
	}

	@Transactional
	public CodeQuestion getRandomCodeQuestion() {
		List<CodeQuestion> allQuestion = codeQuestionDaoImpl.getAllQuestion();
		Random rand = new Random();
		return allQuestion.get(rand.nextInt(allQuestion.size()));
	}

}
