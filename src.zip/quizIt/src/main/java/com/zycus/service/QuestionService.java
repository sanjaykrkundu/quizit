package com.zycus.service;

import java.util.List;

import com.zycus.model.Question;

public interface QuestionService {
	public boolean addQuestion(Question question);

	public List<Question> getAllQuestion();

	public boolean deleteQuestion(int queId);

	public List<Question> getRandomQuestion();
}
