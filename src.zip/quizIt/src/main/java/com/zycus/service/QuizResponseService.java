package com.zycus.service;

import java.util.List;

import com.zycus.model.QuizResponse;

public interface QuizResponseService {
	
	public boolean addQuizResponse(QuizResponse quizResponse);

	public List<QuizResponse> getQuizResponseofStudent(int studentId);
}
