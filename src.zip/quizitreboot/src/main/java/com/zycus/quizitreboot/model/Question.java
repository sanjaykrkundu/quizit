package com.zycus.quizitreboot.model;

import java.util.ArrayList;
import java.util.List;

public class Question {

	private int questionId;
	private String question;
	private Template template;
	private List<TestCase> testCases;

	public Question() {
		template = new Template();
		testCases = new ArrayList<>();
	}

	public Template getTemplate() {
		return template;
	}

	public void setTemplate(Template template) {
		this.template = template;
	}

	public int getQuestionId() {
		return questionId;
	}

	public void setQuestionId(int questionId) {
		this.questionId = questionId;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public List<TestCase> getTestCases() {
		return testCases;
	}

	public void setTestCases(List<TestCase> testCases) {
		this.testCases = testCases;
	}

	@Override
	public String toString() {
		return "Question [questionId=" + questionId + ", question=" + question + ", template=" + template
				+ ", testCases=" + testCases + "]";
	}

}
