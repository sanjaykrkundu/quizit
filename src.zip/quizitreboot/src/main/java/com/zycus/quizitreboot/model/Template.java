package com.zycus.quizitreboot.model;

import java.util.List;

public class Template {

	private String className;
	private String methodName;
	private String returnType;
	private List<String> parameters;

	public Template() {
		className = "ClassName";
		methodName = "methodName";
		returnType = "void";
	}

	public List<String> getParameters() {
		return parameters;
	}

	public void setParameters(List<String> parameters) {
		this.parameters = parameters;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public String getMethodName() {
		return methodName;
	}

	public void setMethodName(String methodName) {
		this.methodName = methodName;
	}

	public String getReturnType() {
		return returnType;
	}

	public void setReturnType(String returnType) {
		this.returnType = returnType;
	}

	public String getTemplate() {
		return generateTemplate();
	}

	public String generateTemplate() {
		String template = "public class " + className + "{\n\n\tpublic static " + returnType + " methodName("
				+ formatParameters()
				+ "){\n\n\t\t/*\n\t\twrite your code here \n\t\tDon't write main method, it'll be created automatically\n\t\t*/\n\n\t}\n\n}";
		return template;
	}

	private String formatParameters() {
		String formattedParameter = "";
		int i = 0;
		for (String parameter : parameters) {
			formattedParameter += ", " + parameter + " arg" + i++ + " ";
		}
		return formattedParameter.replaceFirst(",", "");
	}

	@Override
	public String toString() {
		return "Template [className=" + className + ", methodName=" + methodName + ", returnType=" + returnType
				+ ", parameters=" + parameters + "]";
	}

}
