package com.zycus.quizitreboot.model;

import java.util.List;

public class TestCase {
	private int id;
	private List<String> parameters;
	private String result;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public List<String> getParameters() {
		return parameters;
	}

	public void setParameters(List<String> parameters) {
		this.parameters = parameters;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	
	@Override
	public String toString() {
		return "TestCase [id=" + id + ", parameters=" + parameters + ", result=" + result + "]";
	}

}
