package com.zycus.quizitreboot.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.zycus.quizitreboot.model.Question;
import com.zycus.quizitreboot.model.TestCase;

@Controller
@RequestMapping("/question")
public class MainController {

	@RequestMapping(value = { "/" }, method = RequestMethod.GET)
	public String newQuestion(Model model) {
		model.addAttribute(new Question());
		return "question";
	}

	@RequestMapping(value = { "/" }, method = RequestMethod.POST)
	public String addQuestion(@ModelAttribute("question") Question question, HttpServletRequest request) {
		int totalNoOfParam = 0, totalNoOfTestcases = 0;

		if (request.getParameter("totalNoOfParam") != null) {
			List<String> parameters = new ArrayList<>();

			int tempNoOfParam = Integer.parseInt(request.getParameter("totalNoOfParam"));
			for (int i = 0; i < tempNoOfParam; i++) {
				String param = request.getParameter("param" + i);
				if (param != null && param.length() > 0) {
					parameters.add(param);
					totalNoOfParam++;
				}
			}
			question.getTemplate().setParameters(parameters);
		}

		if (request.getParameter("totalNoOfTestCase") != null) {
			List<TestCase> testcases = new ArrayList<>();
			totalNoOfTestcases = Integer.parseInt(request.getParameter("totalNoOfTestCase"));
			for (int i = 0; i < totalNoOfTestcases; i++) {
				TestCase testcase = new TestCase();
				List<String> parameters = new ArrayList<String>();
				for (int j = 0; j < totalNoOfParam; j++) {
					String param = request.getParameter("tc" + i + "param" + j);
					parameters.add(param);
				}
				testcase.setParameters(parameters);
				testcase.setResult(request.getParameter("tcResult" + i));
				testcases.add(testcase);
			}
			question.setTestCases(testcases);
		}

		System.out.println(question);
		System.out.println(question.getTemplate().generateTemplate());
		return "question";
	}

}
