$(document).ready(function() {
	var btn_addParam = $("#addParam");
	var totalNoOfParam = 0;
	var totalParamInput = 0
	var tcno=0;
	var parameterString;	
	btn_addParam.click(function() {
		var textbox_noOfParam = $("#noOfParam");
		var paramContainer = $("#paramContainer");
		var noOfParam = textbox_noOfParam.val();
		
		if (noOfParam > 0) {
			textbox_noOfParam.hide();
			for (i = 0; i < noOfParam; i++) {
				paramContainer.append("<input type=\"text\" placeholder=\"arg"+ totalNoOfParam+ "\" name=\"param"+ totalNoOfParam+ "\" id=\"param"+ totalNoOfParam+ "\">");
				totalNoOfParam++;
				$("#totalNoOfParam").val(totalNoOfParam);
			}
			textbox_noOfParam.val(1);
			btn_addParam.val("Add More Parameter");
		}
	});

	function viewTemplate() {
		var template = "";
		var className = $("#template\\.className").val();
		var returnType = $("#template\\.returnType").val();
		var methodName = $("#template\\.methodName").val();
		totalParamInput=0;
		parameterString = "";
		var i  = 0;
		$("#paramContainer > input").each(function(){
			var param = $(this).val();
			if(param.length>0){
				parameterString += ", " + param + " arg"+ i++ + " ";
				totalParamInput++;
			}
			 
		});
		parameterString = parameterString.substring(1);

		template = "public class "+ className+ "{\n\n\tpublic static "+ returnType+ " "+ methodName +" ("+  parameterString + "){\n\n\t\t/* write your code here */\n\n\t}\n\n}";
		$("#template").html(template);
	}



	var btn_addTestcases = $("#addTestcases");
	

	function insertTestcaseInput(container,noOfTestcase,noOfParam,firsttime){
		if(firsttime == true){
			container.html("<div><span>"+parameterString.replace(/,/g,"</span><span>")+ "</span></div>");
			//container.html(parameterString);
			tcno = 0;
			
		}
		console.log(noOfTestcase + " "+  noOfParam);
		for (i = 0; i < noOfTestcase; i++) {
			var row = "<div>";
			for (var j =0; j <noOfParam; j++) {
				row += "<input type='text' id='tc" + tcno + "param" + j +"' name='tc" + tcno + "param" + j +"' placeholder='TC " + tcno + " Param " + j +"'>";
			}
			row += "<input type='text' id='tcResult" + tcno + "' name='tcResult" + tcno + "' placeholder='TC Result" + tcno + "'></div>"
			tcno++;
			container.append(row);
		}
	}
	
	btn_addTestcases.click(function() {
		viewTemplate();
		var testcaseContainer = $("#testcaseContainer");
		var textbox_noOfTestcase = $("#noOfTestcase");
		testcaseContainer.html("");
		
		var noOfTestcase = textbox_noOfTestcase.val();

		if (noOfTestcase > 0 && totalParamInput>0) {
			textbox_noOfTestcase.hide();
			insertTestcaseInput(testcaseContainer,noOfTestcase,totalParamInput,true);
			$("#totalNoOfTestCase").val(tcno);
			textbox_noOfTestcase.val(1);
			btn_addTestcases.hide();
		}

	});
	
	
	$("#addMoreTestcase").click(function(){
		insertTestcaseInput($("#testcaseContainer"),1,totalParamInput,false);
	});

});
