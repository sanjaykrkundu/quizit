package test;

public class Temp {

	public static void main(String[] args) {

		int sum = ClassName.method();
		
		
	}

}
