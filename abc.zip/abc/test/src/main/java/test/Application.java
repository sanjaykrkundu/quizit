package test;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.file.Files;
import java.nio.file.Path;

public class Application {

	public static void main(String[] args) throws IOException {
		Path p = Files.createTempFile("Temp", ".java");
		String className = p.toFile().getName().replace(".java", "");
		String classFile = "\n" + "public class " + className + "{\n" + "\n" + "	public static int test() {\n"
				+ "		System.out.println(\"hi\");\n" + "	}\n" + "	\n" + "}";

		String mainClass = "public class Main {\n" + 
				"\n" + 
				"	public static void main(String[] args) {\n" + 
				"\n" + 
				"		int sum = ClassName.method();\n" + 
				"		\n" + 
				"		\n" + 
				"	}\n" + 
				"\n" + 
				"}";
		
		
		Files.write(p, classFile.getBytes());

		System.out.println(p.toFile().getAbsolutePath());

		Runtime.getRuntime().exec("javac " + p.toString());

	}

	private static String streamToString(InputStream ins) {
		String temp = null, output = "";
		BufferedReader in = new BufferedReader(new InputStreamReader(ins));
		try {
			while ((temp = in.readLine()) != null) {
				output += "\n" + temp;
			}
		} catch (IOException e) {
			return null;
		}
		return output.replaceFirst("\n", "");
	}

	private static void runProcess(String command, String input) throws Exception {
		Process pro = Runtime.getRuntime().exec(command);
		if (input != null) {
			BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(pro.getOutputStream()));
			writer.write(input, 0, input.length());
			writer.newLine();
			writer.close();
		}
		pro.waitFor();
		System.out.println(pro.exitValue());
		System.out.println(streamToString(pro.getErrorStream()));
		System.out.println(streamToString(pro.getInputStream()));

	}

}
