package com.zycus.quizit.repository;

public interface UserRepository {
	

}
