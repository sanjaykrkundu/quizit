package com.zycus.quizit.Model;

public class User {

}
