package com.milan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootSampleWebAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootSampleWebAppApplication.class, args);
	}
}
